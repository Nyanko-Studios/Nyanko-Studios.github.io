Thank you for downloading TI-PACMAN.

Inside the .zip file you will find 1 folder:
	TI-84+
		PACMAN_84.8xp - the program file for the game.
		PACMAN_84.txt - the source code for the game.
		FASTKEY_asm.8x9 - the program file for the control input.
		FASTKEY_asm.txt - the source code for the key reading program.

I. About

In order to make the game as small as possible, PACMAN is represented as an `8`, and the only
ghost as a `3`. The pellets are `-`s. There is only one ghost, due to the 16x8 screen, and no
"super pellets" in order to keep the game small. (In one of my lost prototypes they existed, but
were glitchy & had little effect on the difficulty...)

For all intents & purposes, the game is endless.

The game is written TI-BASIC, except for one function in machine code.

II. Program size

For the TI-84 -
	 848 bytes for the main program
	  22 bytes for the "compiled" assembly program
	1409 bytes for variables, matrices, strings, & equations
	~500 bytes of free RAM to run
	In total, about 2.7 kilobytes (2779 bytes) are required

III. Rules

The rules are the same as in the arcade PACMAN.
	Collect all pellets (`-`s) without losing all your lives to the ghost (`3`) to advance.
The game controls are as follows:
	(Y=)  - pause
	D-pad - move PACMAN (`8`)
	ENTER - start, continue, unpause...
	ON    - quit the game

IV. Possible Questions

Q. Why is the ghost so hard?
A. The ghost only goes directly for the player; he has a simple A.I. to reduce program size.

Q. Can I eat the ghost?
A. No; there are no "super/power pellets".

Q. Is there a way to gain extra points?
A. No, there are exactly 80 points per level.

Q. How can I get more lives?
A. By beating a stage. You start with 3.

Q. Where can I view my point/live counter?
A. You can't. There was no space on the screen. You can see how many points you got and your
	score once you run out of lives.

Q. Is there an end?
A. There is, but only due to floating-point number limits. The maximum level is
	estimated to be about (1.25*10^8), or 125 million, with about (10^10)
	points, or 10 billion points.

Q. What is the highest level you've reached?
A. At release, I had reached LV3. As of June 2020, I've reached LV5 with 399 points. LV2 in prototypes.
	Of the about 6 other people that have played the game, none reached LV2.

Q. What's wrong with the ghost? He seems glitchy.
A. He can clip some corners in order to save space. It was too complicated and not worth the
	effort to fix in TI-BASIC.

V. Notes
If you cannot upload the files to your calculator, you have the option of manualy entering the code into the calculator yourself. PV, FV, and PMT are finance variables (APPS->Finance...->VARS). If you manualy input the assembly file yourself, you MUST make sure to enter in the code EXACTLY the same. Failing to do so, if run, may cause your calculator to CRASH, which will ERASE ALL RAM.

VI. Credits

All code except the key processing assembly function was developed by me (Haruki). PACMAN belongs to its respective owners. The program is provided "as is". The developer is in no way responsible for any problems the program may cause.